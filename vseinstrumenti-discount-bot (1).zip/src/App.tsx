import { useState, useEffect } from 'react';
import { Bot, CheckCircle2, AlertCircle, Terminal, HelpCircle } from 'lucide-react';

export default function App() {
  const [status, setStatus] = useState<'loading' | 'ok' | 'error' | 'config_needed'>('loading');

  useEffect(() => {
    fetch('/api/health')
      .then(res => res.json())
      .then(data => {
        if (data.bot === 'missing_token') {
          setStatus('config_needed');
        } else if (data.status === 'ok') {
          setStatus('ok');
        } else {
          setStatus('error');
        }
      })
      .catch(() => setStatus('error'));
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 font-sans">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8 border border-slate-200 text-slate-900">
        <div className="flex items-center gap-4 mb-8">
          <div className="bg-blue-600 p-3 rounded-xl shadow-lg shadow-blue-200">
            <Bot className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold leading-tight">
              VseInstrumenti Discount Bot
            </h1>
            <p className="text-slate-500 text-sm">Мониторинг скидок и уведомления в Telegram</p>
          </div>
          <div className="ml-auto">
            {status === 'ok' ? (
              <span className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold border border-emerald-100">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Работает
              </span>
            ) : status === 'config_needed' ? (
              <span className="flex items-center gap-1.5 px-3 py-1 bg-orange-50 text-orange-700 rounded-full text-xs font-semibold border border-orange-100">
                <AlertCircle className="w-3.5 h-3.5" />
                Нужна настройка
              </span>
            ) : status === 'error' ? (
              <span className="flex items-center gap-1.5 px-3 py-1 bg-red-50 text-red-700 rounded-full text-xs font-semibold border border-red-100">
                <AlertCircle className="w-3.5 h-3.5" />
                Ошибка
              </span>
            ) : (
              <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 text-slate-500 rounded-full text-xs font-semibold animate-pulse">
                Проверка...
              </span>
            )}
          </div>
        </div>

        <div className="space-y-6">
          {status === 'config_needed' && (
            <div className="p-4 bg-orange-50 border border-orange-200 rounded-xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5 shrink-0" />
              <div>
                <h3 className="font-bold text-orange-900 mb-1">Токен не найден!</h3>
                <p className="text-sm text-orange-800">
                  Бот не сможет работать, пока вы не укажете <b>TELEGRAM_BOT_TOKEN</b> в секретах (Secrets) или файле <code>.env</code>.
                </p>
              </div>
            </div>
          )}

          <section className="bg-blue-50 rounded-xl p-5 border border-blue-100">
            <h2 className="flex items-center gap-2 font-bold text-blue-900 mb-3">
              <HelpCircle className="w-5 h-5" />
              Как настроить бота?
            </h2>
            <ol className="list-decimal list-inside space-y-2 text-sm text-blue-800 opacity-90">
              <li>Напишите <b>@BotFather</b> в Telegram и создайте нового бота (/newbot).</li>
              <li>Скопируйте полученный <b>Token</b>.</li>
              <li>Напишите <b>@userinfobot</b>, чтобы узнать свой <b>Chat ID</b>.</li>
              <li>Откройте настройки (Settings) в этом приложении или файл <code>.env</code> и вставьте эти данные.</li>
            </ol>
          </section>

          <section className="bg-emerald-50 rounded-xl p-5 border border-emerald-100 text-emerald-900">
            <h2 className="flex items-center gap-2 font-bold mb-3 text-sm uppercase tracking-wider">
              🚀 Деплой (Render / Railway)
            </h2>
            <div className="space-y-3 text-xs leading-relaxed opacity-90">
              <p>1. Создайте аккаунт на <b>Render.com</b> или <b>Railway.app</b>.</p>
              <p>2. Подключите свой GitHub репозиторий с этим кодом.</p>
              <p>3. В настройках (Environment Variables) добавьте <code>TELEGRAM_BOT_TOKEN</code> и <code>TELEGRAM_CHAT_ID</code>.</p>
              <p>4. <b>Build Command:</b> <code>npm run build</code></p>
              <p>5. <b>Start Command:</b> <code>npm start</code></p>
            </div>
          </section>

          <section className="bg-slate-100 rounded-xl p-5 border border-slate-200">
            <h2 className="flex items-center gap-2 font-bold mb-3 text-sm uppercase tracking-wider">
              🐍 Python Версия
            </h2>
            <p className="text-xs text-slate-600 mb-2">
              Если вам нужен именно Python код (как вы просили), я создал файл <code>bot.py</code>. 
              Вы можете скачать его из панели файлов слева и запустить на своем сервере.
            </p>
            <div className="bg-slate-800 text-slate-300 p-3 rounded-lg text-[10px] font-mono">
              pip install python-telegram-bot requests beautifulsoup4 apscheduler
            </div>
          </section>

          <section>
            <h2 className="flex items-center gap-2 font-bold text-slate-800 mb-3 text-sm uppercase tracking-wider">
              <Terminal className="w-4 h-4" />
              Команды бота
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3 bg-slate-100 rounded-lg border border-slate-200">
                <code className="text-blue-700 font-bold">/start</code>
                <p className="text-xs text-slate-500 mt-1">Приветственное сообщение</p>
              </div>
              <div className="p-3 bg-slate-100 rounded-lg border border-slate-200">
                <code className="text-blue-700 font-bold">/check</code>
                <p className="text-xs text-slate-500 mt-1">Ручной запуск парсинга</p>
              </div>
            </div>
          </section>

          <div className="pt-4 border-t border-slate-100 text-center">
            <p className="text-xs text-slate-400">
              Бот автоматически проверяет сайт ежедневно в 11:00.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
